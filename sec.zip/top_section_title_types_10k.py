from dataclasses import dataclass
from typing import Dict

@dataclass(frozen=True)
class TopSectionIn10K:
    identifier: str
    title: str
    order: int
    level: int = 0
    description: str = ""

# Define an invalid section
InvalidTopSectionIn10K = TopSectionIn10K(
    identifier="invalid",
    title="Invalid",
    order=-1,
    level=1,
)

# Define all 10K sections
ALL_10K_SECTIONS = (
    # Part I
    TopSectionIn10K(identifier="part1", title="Part I: Business", order=1, level=0),
    TopSectionIn10K(identifier="item1", title="Item 1. Business", order=2, level=1),
    TopSectionIn10K(identifier="item1a", title="Item 1A. Risk Factors", order=3, level=1),
    TopSectionIn10K(identifier="item1b", title="Item 1B. Unresolved Staff Comments", order=4, level=1),
    TopSectionIn10K(identifier="item2", title="Item 2. Properties", order=5, level=1),
    TopSectionIn10K(identifier="item3", title="Item 3. Legal Proceedings", order=6, level=1),
    TopSectionIn10K(identifier="item4", title="Item 4. Mine Safety Disclosures", order=7, level=1),
    
    # Part II
    TopSectionIn10K(identifier="part2", title="Part II: Selected Financial Data", order=8, level=0),
    TopSectionIn10K(identifier="item5", title="Item 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities", order=9, level=1),
    TopSectionIn10K(identifier="item6", title="Item 6. Selected Management's Discussion and Analysis of Financial Condition and Results of Operations", order=10, level=1),
    TopSectionIn10K(identifier="item7", title="Item 7. Management's Discussion and Analysis of Financial Condition and Results of Operations", order=11, level=1),
    TopSectionIn10K(identifier="item7a", title="Item 7A. Quantitative and Qualitative Disclosures About Market Risk", order=12, level=1),
    TopSectionIn10K(identifier="item8", title="Item 8. Financial Statements and Supplementary Data", order=13, level=1),
    TopSectionIn10K(identifier="item9", title="Item 9. Changes in and Disagreements with Accountants on Accounting and Financial Disclosure", order=14, level=1),
    TopSectionIn10K(identifier="item9a", title="Item 9A. Controls and Procedures", order=15, level=1),
    TopSectionIn10K(identifier="item9b", title="Item 9B. Other Information", order=16, level=1),
    TopSectionIn10K(identifier="item9c", title="Item 9C. Disclosure Regarding Foreign Currency Transaction Losses", order=17, level=1),
    
    # Part III
    TopSectionIn10K(identifier="part3", title="Part III: Securities Exchange Commission Filings", order=18, level=0),
    TopSectionIn10K(identifier="item10", title="Item 10. Directors, Executive Officers and Corporate Governance", order=19, level=1),
    TopSectionIn10K(identifier="item11", title="Item 11. Executive Compensation", order=20, level=1),
    TopSectionIn10K(identifier="item12", title="Item 12. Security Ownership of Certain Beneficial Owners and Management and Related Stockholder Matters", order=21, level=1),
    TopSectionIn10K(identifier="item13", title="Item 13. Certain Relationships and Related Transactions, and Director Independence", order=22, level=1),
    TopSectionIn10K(identifier="item14", title="Item 14. Principal Accountant Fees and Services", order=23, level=1),
    
    # Part IV
    TopSectionIn10K(identifier="part4", title="Part IV: Exhibits, Financial Statement Schedules", order=24, level=0),
    TopSectionIn10K(identifier="item15", title="Item 15. Exhibits, Financial Statement Schedules", order=25, level=1),
    TopSectionIn10K(identifier="item16", title="Item 16. Form 10-K Summary", order=26, level=1),
)

# Create a mapping from identifier to section
IDENTIFIER_TO_10K_SECTION: Dict[str, TopSectionIn10K] = {
    section.identifier: section for section in ALL_10K_SECTIONS
}

# Define item to part mapping
ITEM_TO_PART = {
    "item1": "part1", "item1a": "part1", "item1b": "part1", "item2": "part1",
    "item3": "part1", "item4": "part1", "item5": "part2", "item6": "part2",
    "item7": "part2", "item7a": "part2", "item8": "part2", "item9": "part2",
    "item9a": "part2", "item9b": "part2", "item9c": "part2", "item10": "part3",
    "item11": "part3", "item12": "part3", "item13": "part3", "item14": "part3",
    "item15": "part4", "item16": "part4"
}

# Define TopSectionType as an alias
TopSectionType = TopSectionIn10K
