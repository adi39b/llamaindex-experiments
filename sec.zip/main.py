from sec_10k_parser import Edgar10KParser
from sec_parser.processing_engine.core import Edgar10QParser
from helper_functions import *
from sec_parser.semantic_tree import TreeBuilder
from sec_parser.semantic_tree import AlwaysNestAsParentRule, AbstractNestingRule, render
import sys

# Force stdout to use UTF-8 on Python 3.7+
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

accession, filing_date = find_sec_filing('19617','10-K')

html_content = download_sec_filing('19617',accession_number=accession)

parser = Edgar10KParser()
elements = parser.parse(html_content)
builder = TreeBuilder()
tree = builder.build(elements)

# Access specific sections
# business_section = [
#     e for e in elements 
#     if e.section_title and "BUSINESS" in e.section_title.upper()
# ]

print(render(list(tree)))

with open('rendered_tree.txt','w',encoding='utf-8') as op_file:
    op_file.write(str(tree.render()))
