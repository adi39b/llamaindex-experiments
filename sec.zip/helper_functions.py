import requests
import re
import io
import pandas as pd
from bs4 import BeautifulSoup

def download_sec_filing(cik, accession_number):
    """
    Download an SEC filing by CIK and accession number.
    
    Args:
        cik: Central Index Key (company identifier)
        accession_number: SEC filing accession number
    
    Returns:
        HTML content of the filing
    """
    # Format CIK and accession number for the URL
    cik_padded = str(cik).lstrip('0')
    accession_formatted = accession_number.replace('-', '')
    
    # Construct the URL for the filing
    url = f"https://www.sec.gov/Archives/edgar/data/{cik_padded}/{accession_number}-index.html"

    print(f"URL: {url}")
    
    #0000320193
    # Add headers to avoid being blocked by SEC.gov
    headers = {
        'User-Agent': 'Example Company Name research@example.com',
        'Accept-Encoding': 'gzip, deflate',
        'Host': 'www.sec.gov'
    }
    
    # Download the filing
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.text, "html.parser")
    table_tag = soup.find("table",class_="tableFile",summary="Data Files")
    rows = table_tag.find_all('tr')
    for row in rows:
        cells = row.find_all("td")
        if len(cells) > 3 and "EXTRACTED" in cells[1].text:
            xbrl_link = f"https://www.sec.gov/{cells[2].a['href']}"
    
    response = requests.get(xbrl_link.replace("_htm.xml",".htm"),headers=headers)
    
    if response.status_code != 200:
        raise Exception(f"Failed to download filing: {response.status_code}")
    
    print(f'Fethed Document from link: {xbrl_link.replace("_htm.xml",".htm")}')
    # SEC returns the complete submission file, which includes metadata and the actual filing
    content = response.content.decode('utf-8')
    
    # Find the beginning of the HTML document
    doc_start = content.find('<HTML')
    if doc_start == -1:
        doc_start = content.find('<html')
    
    # If no HTML tags found, return the full content
    if doc_start == -1:
        return content
    
    # Return just the HTML portion
    return content[doc_start:]

def find_sec_filing(cik, form_type, start_date=None, end_date=None):
    """Get a specific filing accession number for a company."""
    # User-Agent header
    headers = {
        'User-Agent': 'Example Company research@example.com',
    }
    
    # Clean CIK number
    cik = str(cik).lstrip('0')
    
    # Construct URL for SEC API
    url = f"https://data.sec.gov/submissions/CIK{cik.zfill(10)}.json"
    
    # Make request
    response = requests.get(url, headers=headers)
    if response.status_code != 200:
        raise Exception(f"Failed to get filings data: {response.status_code}")
    
    # Parse JSON response
    data = response.json()
    
    # Get recent filings
    recent_filings = data.get('filings', {}).get('recent', {})
    if not recent_filings:
        raise Exception(f"No filings found for CIK {cik}")
    
    # Get forms, dates, and accession numbers
    forms = recent_filings.get('form', [])
    dates = recent_filings.get('filingDate', [])
    accessions = recent_filings.get('accessionNumber', [])
    
    # Filter by form type
    for i, form in enumerate(forms):
        if form == form_type:
            filing_date = dates[i]
            accession = accessions[i]
            return accession, filing_date
    
    raise Exception(f"No {form_type} filing found for CIK {cik}")