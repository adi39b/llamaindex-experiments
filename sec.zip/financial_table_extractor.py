from __future__ import annotations

from typing import TYPE_CHECKING, List, Dict, Optional, Pattern
import re

from sec_parser.processing_steps.abstract_classes.abstract_elementwise_processing_step import (
    AbstractElementwiseProcessingStep,
    ElementProcessingContext,
)
from sec_parser.semantic_elements.table_element.table_element import TableElement
from financial_table_element import FinancialTableElement

if TYPE_CHECKING:  # pragma: no cover
    from sec_parser.semantic_elements.abstract_semantic_element import (
        AbstractSemanticElement,
    )


class FinancialTableExtractor(AbstractElementwiseProcessingStep):
    """
    FinancialTableExtractor identifies and classifies financial tables in 10-K reports.
    
    This processing step looks for tables that contain financial information and
    classifies them as FinancialTableElement instances. It specifically targets:
    
    1. Balance Sheets
    2. Income Statements
    3. Cash Flow Statements
    4. Statement of Stockholders' Equity
    5. Notes to Financial Statements
    
    This helps with extracting structured financial data from the 10-K report.
    """

    def __init__(
        self,
        *,
        types_to_process: set[type[AbstractSemanticElement]] | None = None,
        types_to_exclude: set[type[AbstractSemanticElement]] | None = None,
    ) -> None:
        super().__init__(
            types_to_process=types_to_process,
            types_to_exclude=types_to_exclude,
        )
        
        # Define patterns to identify different types of financial tables
        self._financial_table_patterns: Dict[str, Pattern[str]] = {
            "balance_sheet": re.compile(
                r"(consolidated\s+)?balance\s+sheets?|statements?\s+of\s+(financial\s+)?position", 
                re.IGNORECASE
            ),
            "income_statement": re.compile(
                r"(consolidated\s+)?statements?\s+of\s+(operations|income|earnings|comprehensive\s+income)", 
                re.IGNORECASE
            ),
            "cash_flow": re.compile(
                r"(consolidated\s+)?statements?\s+of\s+cash\s+flows?", 
                re.IGNORECASE
            ),
            "stockholders_equity": re.compile(
                r"(consolidated\s+)?statements?\s+of\s+(stockholders'?|shareholders'?)\s+equity|changes\s+in\s+(stockholders'?|shareholders'?)\s+equity", 
                re.IGNORECASE
            ),
            "notes": re.compile(
                r"notes\s+to\s+(consolidated\s+)?financial\s+statements?", 
                re.IGNORECASE
            ),
        }
        
        # Keywords that typically appear in financial tables
        self._financial_keywords = [
            "assets", "liabilities", "equity", "revenue", "income", "expense", 
            "earnings", "profit", "loss", "total", "net", "cash", "operating", 
            "investing", "financing", "depreciation", "amortization", "tax",
            "deficit", "balance", "retained", "accumulated", "capital"
        ]

    def _process_element(
        self,
        element: AbstractSemanticElement,
        _: ElementProcessingContext,
    ) -> AbstractSemanticElement:
        """
        Process an element to determine if it represents a financial table.
        """
        if not isinstance(element, TableElement):
            return element
            
        # Get the table's caption or find text before the table
        caption = self._get_table_caption(element)
        
        # Check if the caption matches any financial table patterns
        table_type = self._identify_financial_table_type(caption)
        
        # If no match by caption, check table content
        if not table_type and self._contains_financial_data(element):
            table_type = "financial_data"
        
        # If identified as a financial table, convert to FinancialTableElement
        if table_type:
            element.processing_log.add_item(
                log_origin=self.__class__.__name__,
                message=f"Identified financial table type: {table_type}"
            )
            
            return FinancialTableElement.create_from_element(
                element,
                table_type=table_type,
                log_origin=self.__class__.__name__,
            )
            
        return element
    
    def _get_table_caption(self, table_element: TableElement) -> str:
        """
        Get the caption of a table, either from a caption tag or nearby text.
        
        Args:
            table_element: The table element to find caption for
            
        Returns:
            The caption text if found, empty string otherwise
        """
        # Check for HTML caption tag
        caption_tag = table_element.html_tag.find_tag("caption")
        if caption_tag:
            return caption_tag.get_text().strip()
        
        # Check for title in preceding elements (more complex in real implementation)
        # This is a simplified approach
        return table_element.html_tag.get_text()[:200].strip()
    
    def _identify_financial_table_type(self, text: str) -> Optional[str]:
        """
        Identify the type of financial table based on its caption or surrounding text.
        
        Args:
            text: The text to analyze
            
        Returns:
            The identified table type or None if not recognized
        """
        for table_type, pattern in self._financial_table_patterns.items():
            if pattern.search(text):
                return table_type
                
        return None
    
    def _contains_financial_data(self, table_element: TableElement) -> bool:
        """
        Check if a table contains financial data by analyzing its content.
        
        Args:
            table_element: The table element to analyze
            
        Returns:
            True if the table appears to contain financial data, False otherwise
        """
        # Get the table text
        table_text = table_element.text.lower()
        
        # Count occurrences of financial keywords
        keyword_count = sum(1 for keyword in self._financial_keywords if keyword in table_text)
        
        # Check if the table contains currency symbols or numbers with commas
        has_currency = bool(re.search(r'[\$€£¥]', table_text))
        has_financial_numbers = bool(re.search(r'\d{1,3}(,\d{3})+(\.\d+)?', table_text))
        
        # If the table has at least 3 financial keywords and either currency symbols
        # or formatted numbers, it's likely a financial table
        return (keyword_count >= 3) and (has_currency or has_financial_numbers)
