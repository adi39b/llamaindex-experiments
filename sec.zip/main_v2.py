from sec_10k_parser_v2 import Edgar10KParser
from helper_functions import *
from sec_parser.semantic_tree import TreeBuilder
from sec_parser.semantic_tree import AbstractNestingRule, render
from sec_parser.semantic_elements.top_section_title import TopSectionTitle
from sec_parser.semantic_elements import TextElement, TitleElement

# Custom nesting rule for 10-K structure
class SEC10KNestingRule(AbstractNestingRule):
    def __init__(self):
        self.part_items = {
            "part1": ["item1", "item1a", "item1b", "item2", "item3", "item4"],
            "part2": ["item5", "item6", "item7", "item7a", "item8", 
                      "item9", "item9a", "item9b", "item9c"],
            "part3": ["item10", "item11", "item12", "item13", "item14"],
            "part4": ["item15", "item16"]
        }
        # Create reverse mapping from item to parent part
        self.item_to_part = {}
        for part, items in self.part_items.items():
            for item in items:
                self.item_to_part[item] = part
        super().__init__()
    
    def get_potential_parents(self, child):
        """
        Returns all potential parent elements for a child element.
        Used when determining nesting relationships.
        """
        # This will be populated by the TreeBuilder with all elements
        # processed before the current child
        if hasattr(self, '_processed_elements'):
            return self._processed_elements
        return []
        
    def _should_be_nested_under(self, parent, child):
        # Handle Part > Item nesting
        if isinstance(parent, TopSectionTitle) and isinstance(child, TopSectionTitle):
            if parent.section_type.level == 0 and child.section_type.level == 1:
                return child.section_type.identifier in self.part_items.get(
                    parent.section_type.identifier, []
                )
                
        # Handle Item > Subitem nesting
        if isinstance(parent, TopSectionTitle) and isinstance(child, TopSectionTitle):
            if parent.section_type.level == 1 and child.section_type.level == 2:
                return True
                
        # Nest content under nearest section title
        if isinstance(parent, TopSectionTitle) and not isinstance(child, TitleElement):
            return True
            
        return False


def get_rules():
    rules = [SEC10KNestingRule()]
    return rules

# Main execution
accession, filing_date = find_sec_filing('72971', '10-K')
html_content = download_sec_filing('72971', accession_number=accession)

# Parse the document
parser = Edgar10KParser()
elements = parser.parse(html_content)

# Build the tree with custom nesting rules
builder = TreeBuilder(get_rules=get_rules)
tree = builder.build(elements)

# Render the tree
#print(render(list(tree)))

with open('rendered_tree.txt', 'w', encoding='utf-8') as op_file:
    print(render(list(tree)))
    op_file.write(render(list(tree)))