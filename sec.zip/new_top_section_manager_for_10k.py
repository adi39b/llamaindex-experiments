from __future__ import annotations

import re
import warnings
from collections import defaultdict
from dataclasses import dataclass
from typing import TYPE_CHECKING

from sec_parser.processing_steps.abstract_classes.abstract_elementwise_processing_step import (
    AbstractElementwiseProcessingStep,
    AbstractProcessingStep,
    ElementProcessingContext,
)
from sec_parser.semantic_elements.top_section_title import TopSectionTitle
from top_section_title_types_10k import (
    IDENTIFIER_TO_10K_SECTION,
    ITEM_TO_PART,  # Removed duplicate IDENTIFIER_TO_10K_SECTION
    InvalidTopSectionIn10K, TopSectionType, TopSectionIn10K
)

if TYPE_CHECKING:  # pragma: no cover
    from sec_parser.semantic_elements.abstract_semantic_element import (
        AbstractSemanticElement,
    )

part_pattern = re.compile(
    r"^(part\s*)(i+)([\s\-:*]+)(.*)$",
    re.IGNORECASE
)

item_pattern = re.compile(
    r"^(item\s*)(\d+[a-z]?)([\s\-:*\.]+)(.*)$",
    re.IGNORECASE
)

@dataclass
class _Candidate:
    section_type: TopSectionType
    element: AbstractSemanticElement

class MissingPartHeaderCreator(AbstractProcessingStep):
    def __init__(self):
        super().__init__()
        self.item_to_part = ITEM_TO_PART
        self.parts_found = set()
        self.items_found = set()
        
    def _process(self, elements):
        # First pass: identify all parts and items that exist
        for element in elements:
            if isinstance(element, TopSectionTitle):
                if element.section_type.level == 0:  # Part
                    self.parts_found.add(element.section_type.identifier)
                elif element.section_type.level == 1:  # Item
                    self.items_found.add(element.section_type.identifier)
                    
        # Second pass: create missing parts that have items
        result = []
        missing_parts = []
        
        # Find which parts are missing but have items
        for item in self.items_found:
            parent_part = self.item_to_part.get(item)
            if parent_part and parent_part not in self.parts_found:
                missing_parts.append(parent_part)
                
        # Create synthetic part headers for missing parts
        for part_id in set(missing_parts):
            section_type = IDENTIFIER_TO_10K_SECTION.get(part_id)
            if section_type:
                part_title = TopSectionTitle(
                    level=0,
                    section_type=section_type,
                    html_tag=None,  # Synthetic element
                )
                result.append(part_title)
        
        # Add all original elements
        result.extend(elements)
        return result

class TopSectionManagerFor10K(AbstractElementwiseProcessingStep):
    _NUM_ITERATIONS = 2

    def __init__(
        self,
        *,
        types_to_process: set[type[AbstractSemanticElement]] | None = None,
        types_to_exclude: set[type[AbstractSemanticElement]] | None = None,
    ) -> None:
        super().__init__(
            types_to_process=types_to_process,
            types_to_exclude=types_to_exclude,
        )
        self._candidates: list[_Candidate] = []
        self._selected_candidates: tuple[_Candidate, ...] | None = None
        self._last_part: str = "?"
        self._last_order_number = float("-inf")

    @classmethod
    def is_match_part_or_item(cls, text: str) -> bool:
        part_match = cls.match_part(text) is not None
        item_match = cls.match_item(text) is not None
        return part_match or item_match

    @staticmethod
    def match_part(text: str) -> str | None:
        if match := part_pattern.match(text):
            # Return the length of the roman numeral in group(2)
            return str(len(match.group(2)))
        return None

    @staticmethod
    def match_item(text: str) -> str | None:
        if match := item_pattern.match(text):
            # Return the numeric part (with optional letter) from group(2)
            return match.group(2).lower()
        return None

    def _process_element(
        self,
        element: AbstractSemanticElement,
        context: ElementProcessingContext,
    ) -> AbstractSemanticElement:
        if context.iteration == 0:
            self._process_iteration_0(element)
            return element

        if context.iteration == 1:
            return self._process_iteration_1(element)

        msg = f"Invalid iteration: {context.iteration}"
        raise ValueError(msg)

    def _process_iteration_0(self, element: AbstractSemanticElement) -> None:
        self._identify_candidate(element)

    def _process_iteration_1(self, element: AbstractSemanticElement) -> AbstractSemanticElement:
        if self._selected_candidates is None:
            self._selected_candidates = self._select_candidates()

        return self._process_selected_candidates(element)

    def _identify_candidate(self, element: AbstractSemanticElement) -> None:
        candidate = None

        if part := self.match_part(element.text):
            self._last_part = part
            section_type = self._get_section_type(f"part{self._last_part}")
            if section_type is InvalidTopSectionIn10K:
                warnings.warn(
                    f"Invalid section type for part{self._last_part}. Defaulting to InvalidTopSectionIn10K.",
                    UserWarning,
                    stacklevel=8,
                )
            candidate = _Candidate(section_type, element)
        elif item := self.match_item(element.text):
            section_type = self._get_section_type(f"item{item}")
            if section_type is InvalidTopSectionIn10K:
                warnings.warn(
                    f"Invalid section type for item{item}. Defaulting to InvalidTopSectionIn10K.",
                    UserWarning,
                    stacklevel=8,
                )
            candidate = _Candidate(section_type, element)

        if candidate is not None:
            self._candidates.append(candidate)
            element.processing_log.add_item(
                message=f"Identified as candidate: {candidate.section_type.identifier}",
                log_origin=self.__class__.__name__,
            )

    def _get_section_type(self, identifier: str) -> TopSectionType:
        return IDENTIFIER_TO_10K_SECTION.get(identifier, InvalidTopSectionIn10K)

    def _select_candidates(self) -> tuple[_Candidate, ...]:
        grouped_candidates = defaultdict(list)
        for candidate in self._candidates:
            grouped_candidates[candidate.section_type].append(candidate.element)

        def select_element(elements: list[AbstractSemanticElement]) -> AbstractSemanticElement:
            if len(elements) == 1:
                return elements[0]
            elements_without_table = [
                element
                for element in elements
                if not element.html_tag.contains_tag("table", include_self=True)
            ]
            if len(elements_without_table) >= 1:
                return elements_without_table[0]
            return elements[0]

        return tuple(
            _Candidate(
                section_type=section_type,
                element=select_element(element),
            )
            for section_type, element in grouped_candidates.items()
        )

    def _process_selected_candidates(self, element: AbstractSemanticElement) -> AbstractSemanticElement:
        if self._selected_candidates is None:
            return element

        for candidate in self._selected_candidates:
            if candidate.element is element:
                if candidate.section_type.identifier.startswith('part'):
                    self._last_order_number = candidate.section_type.order
                    self._last_part = candidate.section_type.identifier
                elif candidate.section_type.identifier.startswith('item'):
                    expected_part = self._get_parent_part(candidate.section_type.identifier)
                    if expected_part != self._last_part:
                        continue

                if candidate.section_type.order >= self._last_order_number:
                    self._update_last_order_number(element, candidate.section_type.order)
                    return self._create_top_section_title(candidate)
                else:
                    self._log_order_number_not_greater(element, candidate.section_type.order)
                    return element

        return element

    def _get_parent_part(self, item_identifier: str) -> str:
        """Get the parent part for an item identifier"""
        return ITEM_TO_PART.get(item_identifier, '') 

    def _update_last_order_number(self, element: AbstractSemanticElement, order: float) -> None:
        message = f"this.order={order} last_order_number={self._last_order_number}."
        element.processing_log.add_item(
            message=message,
            log_origin=self.__class__.__name__,
        )
        self._last_order_number = order

    def _log_order_number_not_greater(self, element: AbstractSemanticElement, order: float) -> None:
        message = f"Order number {order} is not greater than last order number {self._last_order_number}."
        element.processing_log.add_item(
            message=message,
            log_origin=self.__class__.__name__,
        )

    def _create_top_section_title(
        self, candidate: _Candidate,
    ) -> AbstractSemanticElement:
        return TopSectionTitle.create_from_element(
            candidate.element,
            level=candidate.section_type.level,
            section_type=candidate.section_type,
            log_origin=self.__class__.__name__,
        )
