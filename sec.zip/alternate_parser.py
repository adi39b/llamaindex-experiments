from helper_functions import *
import requests
from lxml import html
from io import BytesIO
import time
import logging
from lxml import html
from io import StringIO

# Initialize the HTML document parser


def init_html_doc(html_string):
    # Create parser with SEC document optimizations
    parser = html.HTMLParser(
        remove_comments=True,
        encoding='utf-8',
        huge_tree=True  # Necessary for large SEC filings
    )

    # Parse HTML and get root element
    doc_tree = html.parse(StringIO(html_string), parser=parser)
    root = doc_tree.getroot()  # Correct way to access root element

    # Make exhibit links absolute
    root.make_links_absolute("https://www.sec.gov")

    # Register namespaces for XBRL and EDGAR
    xpath_namespaces = {
        'ix': 'http://www.xbrl.org/2003/instance',
        'edgar': 'http://www.sec.gov/edgar/document'
    }

    return root, xpath_namespaces


BALANCE_SHEET_XPATHS = [
    '//h2[contains(., "Consolidated Balance Sheet")]/following::table[1]',
    '//ix:nonnumeric[@name="us-gaap:Assets"]/ancestor::table',
    '//table[.//th[contains(., "Total Assets")]]'
]

def extract_text_content(element_list):
    """Extracts and cleans text from lxml elements"""
    texts = []
    for elem in element_list:
        # Handle different element types
        if isinstance(elem, html.HtmlElement):
            # Clean whitespace and join text
            text = ' '.join(elem.text_content().split())
            texts.append(text)
        elif hasattr(elem, 'xpath'):  # For PDF wrapper elements
            texts.append('\n'.join(elem.xpath('//text()')))
        else:
            texts.append(str(elem))
    return '\n\n'.join(texts)


def extract_10k_sections(html_doc):
    # Phase 1: Direct Extraction
    results = {
        'item1_business': None,
        'balance_sheet': None
    }

    # A. Find Item 1: Business
    if not results['item1_business']:
        # Method 1: Standard location
        # results['item1_business'] = html_doc.xpath(
        #     '//section[contains(., "Part I")]//*[self::h2 or self::div][contains(., "Item 1. Business")]/following-sibling::*')
        results['item1_business'] = extract_text_content(html_doc.xpath(
            "//*[contains(translate(., 'ITEM', 'item'), 'item 1') and contains(translate(., 'BUSINESS', 'business'), 'business')]/following::*[not(contains(translate(., 'ITEM', 'item'), 'item '))]"))

        # Method 2: Incorporated references
        if not results['item1_business']:
            incorporated_ref = html_doc.xpath(
                '//*[contains(., "incorporated by reference")]')
            if incorporated_ref:
                exhibit_13 = extract_text_content(html_doc.xpath(
                    '//a[contains(., "Exhibit 13")]/@href'))
                print(f"Exhibit 13 Path : {exhibit_13}")
                results['item1_business'] = f"Exhibit 13 Path : {exhibit_13}"
                # results['item1_business'] = fetch_and_parse(exhibit_13).xpath(BUSINESS_XPATH)

    # B. Find Consolidated Balance Sheet
    balance_sheet_locations = [
        ('//*[contains(., "Consolidated Balance Sheet")]', 'exact match'),
        ('//*[contains(., "Financial Position")]', 'alternative title'),
        ('//table[@class="financials"]', 'generic table detection'),
        ('//ix:nonnumeric[@name="us-gaap:Assets"]', 'XBRL tagging')
    ]

    for xpath, method in balance_sheet_locations:
        if not results['balance_sheet']:
            results['balance_sheet'] = extract_text_content(html_doc.xpath(xpath))
            if results['balance_sheet']:
                print(f"Found via {method}")

    # Phase 2: Exhibit Fallback
    if not results['balance_sheet']:
        exhibits = html_doc.xpath(
            '//div[@id="exhibits"]//a[contains(@href, "EX-")]')
        financial_exhibits = [
            extract_text_content(e) for e in exhibits if '21' in e or '99.1' in e or 'financial' in e.text.lower()]

        results['balance_sheet'] = financial_exhibits

        # for exhibit in financial_exhibits:
        #     exhibit_content = fetch_and_parse(exhibit.attrib['href'])
        #     results['balance_sheet'] = exhibit_content.xpath(BALANCE_SHEET_XPATHS)
        #     if results['balance_sheet']: break

    return results


if __name__ == '__main__':
    accession, filing_date = find_sec_filing('19617', '10-K')
    html_content = download_sec_filing('19617', accession_number=accession)
    # Usage:
    # html_string = """<your entire HTML document string>"""
    html_doc, ns = init_html_doc(html_content)

    # Now use in XPath queries with namespace handling:
    # results = html_doc.xpath('//ix:nonnumeric', namespaces=ns)

    sections = extract_10k_sections(html_doc)
    with open('alternate_approach.txt','w',encoding='utf-8') as op_file:
        op_file.write(str(sections))