from __future__ import annotations

from typing import TYPE_CHECKING, Optional, Dict, Any, List

from sec_parser.semantic_elements.table_element.table_element import TableElement

if TYPE_CHECKING:  # pragma: no cover
    from sec_parser.semantic_elements.abstract_semantic_element import (
        AbstractSemanticElement,
    )


class FinancialTableElement(TableElement):
    """
    FinancialTableElement represents a table containing financial data in a 10-K report.
    
    This element extends the standard TableElement with additional metadata about
    the type of financial information it contains (e.g., balance sheet, income statement).
    It also provides methods for extracting structured financial data from the table.
    """

    def __init__(
        self,
        html_tag,
        *,
        table_type: str,
        log_origin: Optional[str] = None,
        processing_log = None,
    ) -> None:
        super().__init__(html_tag, log_origin=log_origin, processing_log=processing_log)
        self._table_type = table_type
        
    @property
    def table_type(self) -> str:
        """
        Get the type of financial table.
        
        Returns:
            A string identifying the type of financial table (e.g., 'balance_sheet',
            'income_statement', 'cash_flow', etc.)
        """
        return self._table_type
    
    @staticmethod
    def create_from_element(
        element: AbstractSemanticElement,
        *,
        table_type: str,
        log_origin: Optional[str] = None,
    ) -> FinancialTableElement:
        """
        Create a FinancialTableElement from another element.
        
        Args:
            element: The source element to convert
            table_type: The type of financial table
            log_origin: The origin of the log entry
            
        Returns:
            A new FinancialTableElement
        """
        processing_log = element.processing_log.copy()
        if log_origin:
            processing_log.add_item(
                log_origin=log_origin,
                message=f"Converted to FinancialTableElement with type: {table_type}",
            )
            
        return FinancialTableElement(
            element.html_tag,
            table_type=table_type,
            log_origin=log_origin,
            processing_log=processing_log,
        )
    
    def extract_structured_data(self) -> Dict[str, Any]:
        """
        Extract structured financial data from the table.
        
        Returns:
            A dictionary containing the structured financial data
        """
        # This would be a more complex implementation in practice
        # Here's a simplified version that extracts row/column headers and data
        
        structured_data = {
            "type": self._table_type,
            "headers": self._extract_headers(),
            "data": self._extract_data(),
        }
        
        return structured_data
    
    def _extract_headers(self) -> Dict[str, List[str]]:
        """
        Extract column and row headers from the table.
        
        Returns:
            A dictionary with 'columns' and 'rows' keys containing lists of headers
        """
        # Get the HTML table
        table = self.html_tag.find_tag("table")
        if not table:
            return {"columns": [], "rows": []}
            
        headers = {"columns": [], "rows": []}
        
        # Extract column headers (typically in thead or first row)
        thead = table.find_tag("thead")
        if thead:
            th_elements = thead.find_all_tags("th")
            headers["columns"] = [th.get_text().strip() for th in th_elements]
        else:
            # If no thead, use the first row
            first_row = table.find_tag("tr")
            if first_row:
                th_elements = first_row.find_all_tags("th") or first_row.find_all_tags("td")
                headers["columns"] = [th.get_text().strip() for th in th_elements]
        
        # Extract row headers (typically the first cell of each row)
        rows = table.find_all_tags("tr")[1:]  # Skip the header row
        for row in rows:
            cells = row.find_all_tags("th") or row.find_all_tags("td")
            if cells:
                headers["rows"].append(cells[0].get_text().strip())
                
        return headers
    
    def _extract_data(self) -> List[List[str]]:
        """
        Extract the data cells from the table.
        
        Returns:
            A 2D list of strings representing the table data
        """
        # Get the HTML table
        table = self.html_tag.find_tag("table")
        if not table:
            return []
            
        # Get all rows
        rows = table.find_all_tags("tr")
        
        # Skip the header row
        data_rows = []
        for row in rows[1:]:
            cells = row.find_all_tags("td")
            data_rows.append([cell.get_text().strip() for cell in cells])
            
        return data_rows
