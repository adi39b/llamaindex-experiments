from __future__ import annotations

from typing import TYPE_CHECKING, Callable

from sec_parser.processing_engine.html_tag_parser import (
    AbstractHtmlTagParser,
    HtmlTagParser,
)
from sec_parser.processing_engine.types import ParsingOptions
from sec_parser.processing_engine.core import AbstractSemanticElementParser, Edgar10QParser
from sec_parser.processing_steps.empty_element_classifier import EmptyElementClassifier
from sec_parser.processing_steps.highlighted_text_classifier import (
    HighlightedTextClassifier,
)
from sec_parser.processing_steps.image_classifier import ImageClassifier
from sec_parser.processing_steps.individual_semantic_element_extractor.individual_semantic_element_extractor import (
    IndividualSemanticElementExtractor,
)
from sec_parser.processing_steps.individual_semantic_element_extractor.single_element_checks.image_check import (
    ImageCheck,
)
from sec_parser.processing_steps.individual_semantic_element_extractor.single_element_checks.table_check import (
    TableCheck,
)
# from sec_parser.processing_steps.individual_semantic_element_extractor.single_element_checks.top_section_title_check import (
#     TopSectionTitleCheck,
# )
from sec_parser.processing_steps.individual_semantic_element_extractor.single_element_checks.xbrl_tag_check import (
    XbrlTagCheck,
)
from sec_parser.processing_steps.introductory_section_classifier import (
    IntroductorySectionElementClassifier,
)
from sec_parser.processing_steps.page_header_classifier import PageHeaderClassifier
from sec_parser.processing_steps.page_number_classifier import PageNumberClassifier
from sec_parser.processing_steps.supplementary_text_classifier import (
    SupplementaryTextClassifier,
)
from sec_parser.processing_steps.table_classifier import TableClassifier
from sec_parser.processing_steps.table_of_contents_classifier import (
    TableOfContentsClassifier,
)
from sec_parser.semantic_elements.table_element.table_element import TableElement
from sec_parser.processing_steps.text_classifier import TextClassifier
from sec_parser.processing_steps.text_element_merger import TextElementMerger
from sec_parser.processing_steps.title_classifier import TitleClassifier
from sec_parser.processing_steps.top_section_manager_for_10q import TopSectionManagerFor10Q
from top_section_manager_for_10k import (
    TopSectionManagerFor10K,MissingPartHeaderCreator
)
from sec_parser.semantic_elements.highlighted_text_element import HighlightedTextElement
from sec_parser.semantic_elements.semantic_elements import (
    TextElement,
    NotYetClassifiedElement,
)

# pragma: no cover
from sec_parser.processing_steps.abstract_classes.abstract_processing_step import (
    AbstractProcessingStep,
)
from sec_parser.processing_steps.individual_semantic_element_extractor.single_element_checks.abstract_single_element_check import (
    AbstractSingleElementCheck,
)
from sec_parser.semantic_elements.abstract_semantic_element import (
    AbstractSemanticElement,
)


def _is_match_part_or_item(text: str) -> bool:
    return TopSectionManagerFor10K.is_match_part_or_item(text)


class TopSectionTitleCheck(AbstractSingleElementCheck):
    def contains_single_element(self, element: AbstractSemanticElement) -> bool | None:
        match_count = element.html_tag.count_text_matches_in_descendants(
            _is_match_part_or_item,
            exclude_links=True,
        )

        if match_count >= 1:
            return False

        return None


class Edgar10KParser(AbstractSemanticElementParser):
    """
    The Edgar10KParser class is responsible for parsing SEC EDGAR 10-K
    annual reports. It transforms the HTML documents into a list
    of semantic elements. Each element in this list represents a part of
    the visual structure of the original document.

    10-K reports are annual filings that contain comprehensive information
    about a company's financial performance, risks, and operations.
    This parser handles the specific structure and sections found in 10-K reports,
    which typically include:

    1. Business description
    2. Risk factors
    3. Management discussion and analysis (MD&A)
    4. Financial statements
    5. Notes to financial statements
    6. Management and corporate governance information
    7. Executive compensation
    """

    def get_default_steps(
        self,
        get_checks: Callable[[],
                             list[AbstractSingleElementCheck]] | None = None,
    ) -> list[AbstractProcessingStep]:
        return [
            IndividualSemanticElementExtractor(
                get_checks=get_checks or self.get_default_single_element_checks,
            ),
            ImageClassifier(types_to_process={NotYetClassifiedElement}),
            EmptyElementClassifier(types_to_process={NotYetClassifiedElement}),
            TableClassifier(types_to_process={NotYetClassifiedElement}),
            TableOfContentsClassifier(
                types_to_process={TableElement}),
            TopSectionManagerFor10K(
                types_to_process={NotYetClassifiedElement}),
            MissingPartHeaderCreator(),
            IntroductorySectionElementClassifier(),
            TextClassifier(types_to_process={NotYetClassifiedElement}),
            HighlightedTextClassifier(types_to_process={TextElement}),
            SupplementaryTextClassifier(
                types_to_process={TextElement, HighlightedTextElement},
            ),
            PageHeaderClassifier(
                types_to_process={TextElement, HighlightedTextElement},
            ),
            PageNumberClassifier(
                types_to_process={TextElement, HighlightedTextElement},
            ),
            TitleClassifier(types_to_process={HighlightedTextElement}),
            TextElementMerger(),
        ]

    def get_default_single_element_checks(self) -> list[AbstractSingleElementCheck]:
        return [
            TableCheck(),
            XbrlTagCheck(),
            ImageCheck(),
            TopSectionTitleCheck(),
        ]
